# Karne Samhitha Reddy — Cloud & DevOps Portfolio

## Files
- index.html — portfolio structure/content
- style.css — professional responsive design
- script.js — animations, mobile menu, scroll progress, and voice introduction
- profile.png — uploaded professional portrait

## How to run
1. Keep all four files in the same folder.
2. Double-click `index.html`, or open it with VS Code + Live Server.
3. Click **Listen to my introduction** to hear the browser's English voice.

## Important voice note
The site uses the browser's built-in Web Speech API and prefers a voice whose installed name suggests a female English voice. The exact available voice depends on the browser/operating system. The portfolio does not send the recording to a server.

## Submission
For a college assignment, submit the complete folder (or the ZIP) so the image and code stay together.
