// Portfolio interactions: scroll reveal, progress bar, mobile menu, cursor glow,
// and a browser-native spoken introduction with a female-voice preference when available.

const intro = `Hi, I'm Karne Samhitha Reddy. I'm currently pursuing a BSc in Cloud Computing at Loyola Academy. I'm passionate about cloud computing, DevOps and cloud security. I'm building practical skills in AWS, Linux, networking, Docker, Terraform, CI/CD and monitoring. My goal is to keep learning, build reliable cloud solutions, and grow as a Cloud and DevOps professional. Thanks for visiting my portfolio.`;

const voiceBtn = document.getElementById("voiceBtn");

function chooseFemaleVoice() {
  const voices = window.speechSynthesis.getVoices();
  if (!voices.length) return null;

  // Browser/OS voice names vary. Prefer voices whose names commonly indicate
  // a female English voice, then fall back to a natural English voice.
  const femaleHints = [
    "female", "zira", "samantha", "karen", "victoria", "ava",
    "aria", "jenny", "susan", "hazel", "libby", "sara", "google uk english female"
  ];
  const english = voices.filter(v => /^en(-|_)/i.test(v.lang));
  const female = english.find(v =>
    femaleHints.some(h => v.name.toLowerCase().includes(h))
  );
  return female || english.find(v => /en-IN|en-GB|en-US/i.test(v.lang)) || english[0] || voices[0];
}

function updateVoiceButton(speaking) {
  voiceBtn.innerHTML = speaking ? "<span>■</span> Stop introduction" : "<span>▶</span> Listen to my introduction";
}

voiceBtn.addEventListener("click", () => {
  if (!("speechSynthesis" in window)) {
    alert("Your browser does not support voice playback. Please open this portfolio in a modern browser.");
    return;
  }
  if (speechSynthesis.speaking) {
    speechSynthesis.cancel();
    updateVoiceButton(false);
    return;
  }
  const utterance = new SpeechSynthesisUtterance(intro);
  const voice = chooseFemaleVoice();
  if (voice) utterance.voice = voice;
  utterance.lang = "en-IN";
  utterance.rate = 0.94;
  utterance.pitch = 1.08;
  utterance.onend = () => updateVoiceButton(false);
  utterance.onerror = () => updateVoiceButton(false);
  speechSynthesis.speak(utterance);
  updateVoiceButton(true);
});

speechSynthesis?.addEventListener?.("voiceschanged", () => {});

const reveals = document.querySelectorAll(".reveal");
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
reveals.forEach(el => observer.observe(el));

const progress = document.querySelector(".progress");
window.addEventListener("scroll", () => {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = `${(window.scrollY / max) * 100}%`;
});

const menuBtn = document.querySelector(".menu-btn");
const navLinks = document.querySelector(".nav-links");
menuBtn.addEventListener("click", () => navLinks.classList.toggle("open"));
navLinks.querySelectorAll("a").forEach(a => a.addEventListener("click", () => navLinks.classList.remove("open")));

const glow = document.querySelector(".cursor-glow");
window.addEventListener("pointermove", e => {
  glow.style.left = `${e.clientX}px`;
  glow.style.top = `${e.clientY}px`;
});
